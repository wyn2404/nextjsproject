import { GitHub } from "@mui/icons-material";
import { Avatar, Button, IconButton } from "@mui/material";

const Headers = () => {
  return (
    <>
      <header className="flex justify-between mt-2 pr-2 pl-2 border-gray-400 border-b pb-1 mb-4">
        <Avatar
          alt="wyn2404"
          src="https://wallpapers.com/images/high/yae-miko-genshin-pfp-n8tiumjfpiosy9fn.webp"
          sx={{ width: 36, height: 36 }}
        />
        <div>
          <Button className="text-rose-400">Api</Button>
          <Button className="text-rose-400">Gallery</Button>
          <Button className="text-rose-400">Doc</Button>
        </div>
        <IconButton className="text-rose-400">
          <GitHub></GitHub>
        </IconButton>
      </header>
    </>
  );
};
export default Headers;
