"use client";
import React, { createContext, useEffect, useState } from "react";

export const ImageContext = createContext({});

export const ImageProvider: React.FC<any> = ({ children }: any) => {
  const [DataImage, setDataImage] = useState([]);
  useEffect(() => {
    const FetchImages = async () => {
      await fetch("https://yande.re/post.json?tags=rating:safe")
        .then((res) => res.json())
        .then((data) => {
          setDataImage(data);
          console.log(data, "Data From Context");
        });
    };
    FetchImages();
  }, []);
  return (
    <>
      <ImageContext.Provider value={{ DataImage }}>
        {children}
      </ImageContext.Provider>
    </>
  );
};
