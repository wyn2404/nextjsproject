"use client";
import { Box } from "@mui/material";
import Image from "next/image";
import { useEffect, useState } from "react";

interface ImageType {
  id: number;
  author: string;
  source: string;
  sample_url: string;
  sample_width: number;
  sample_height: number;
}

export default function Home() {
  const Numbers = 5;
  const [DataImage, setDataImage] = useState<ImageType[]>([]);
  useEffect(() => {
    const FetchImages = async () => {
      await fetch("https://yande.re/post.json?tags=rating:safe")
        .then((res) => res.json())
        .then((data) => {
          setDataImage(data);
          //console.log(data, "Data From Context");
        });
    };
    FetchImages();
  }, []);
  return (
    <>
      <main className="flex justify-center flex-col">
        <Box component={"span"} className="w-72 h-auto">
          {DataImage[Numbers] && (
            <Image
              src={DataImage[Numbers].sample_url}
              width={DataImage[Numbers].sample_width}
              height={DataImage[Numbers].sample_height}
              alt={String(DataImage[Numbers].id)}
              className="rounded"
            />
          )}
        </Box>
        <Box className="bg-sky-500 w-20">
          <span>Hello World From WYN2404</span>
        </Box>
      </main>
    </>
  );
}
